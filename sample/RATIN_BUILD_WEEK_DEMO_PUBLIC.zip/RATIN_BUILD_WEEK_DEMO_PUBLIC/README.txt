Drop all five PDF files together on the demo upload button.
These files are sanitized public-source exhibits or controlled synthetic exhibits.
